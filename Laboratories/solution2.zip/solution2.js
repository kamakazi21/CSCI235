/* (1) 	Display in a pretty format information about the total number of customers who submitted empty orders, i.e. orders with no lines. */;



/* (2)	Display in a pretty format information about the available quantities of parts (availqty), that have retail price greater than 908. List only information about the available quantities, and retail prices. */;



/* (3)	Display in a pretty format information about the customers from the nations of JORDAN or MALAWI. Do not list information about the submitted orders. */;



/* (4)	Display in a pretty format information about the customers whose account balance (acctbal) is less then 122 and about the parts that have size less than 3. In a relation to customers, list only information about the customer keys and account balances. In a relation to parts, list only information about part key and part size. */;



/* (5)	Display in a pretty format information about the part keys and the supplier keys of all suppliers who supplied at least one part that has a retail price equal to 909 and a size equal to 12. */;





