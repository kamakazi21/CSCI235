
db.tpchr.insert ( {"_id":"1000","SUPPLIER": { "supplier_id":"1", "supplier key":NumberInt("1"),"name":"Supplier#000000001", "address":"sdrGnXCDRcfriBvY0KL,ipCanOTyK t NN1", "nation":"MOZAMBIQUE", "phone":"30-918-335-1736", "acctbal":5755.94} }  );
db.tpchr.insert ( {"_id":"2000","SUPPLIER": { "supplier_id":"2", "supplier key":NumberInt("2"),"name":"Supplier#000000002", "address":"sdsthghjhjngjfkmyukuiklmiglmih", "nation":"INDIA", "phone":"30-918-335-1735", "acctbal":2345.95} }  );
db.tpchr.insert ( {"_id":"3000","SUPPLIER": { "supplier_id":"3", "supplier key":NumberInt("3"),"name":"Supplier#000000003", "address":"imlknyuiknertyervtarcwetr", "nation":"JAPAN", "phone":"30-918-335-1734", "acctbal":34.89} }  );
db.tpchr.insert ( {"_id":"4000","SUPPLIER": { "supplier_id":"4", "supplier key":NumberInt("4"),"name":"Supplier#000000004", "address":"ECREWRWestcertverterSVERTV", "nation":"INDIA", "phone":"30-918-335-1733", "acctbal":574.23} }  );
db.tpchr.insert ( {"_id":"5000","SUPPLIER": { "supplier_id":"5", "supplier key":NumberInt("5"),"name":"Supplier#000000005", "address":"213235235ECRSDFsdfvgdfs", "nation":"CHINA", "phone":"30-918-335-1732", "acctbal":5334.56} }  );
